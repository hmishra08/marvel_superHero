// var hash = md5("value");


let public_key = "feb0cde62295caf63935ea99cc93963b";
let private_key = "6c4aa04c14d7849fe4996daff37e4d4e2cde2d66";
const ts = 1;
const hash = md5(1 + private_key + public_key)
// console.log(hash)

// let heroWrapper = document.querySelector('.heroList')
var heroList = [];

let searcBtn = document.querySelector("#searchBtn");
if(searcBtn) {
    searcBtn.addEventListener("click", searchList)
}

function searchList() {
    let inputSearch = document.querySelector(".searchBox input").value;
    console.log("input---",inputSearch)
    let searchHero = heroList.filter(el=>{
        return el.name.toLowerCase().includes(inputSearch.toLowerCase());
    })
    console.log(searchHero);
    clearList();
    createSuperHeroList(searchHero)
}

async function fetchList() {
    let result = await fetch(`https://gateway.marvel.com/v1/public/characters?ts=1&apikey=feb0cde62295caf63935ea99cc93963b&hash=${hash}`)
    return result;
}

fetchList()
    .then((response) => {
        return response.json();
    }).then((data) => {
        let result = data.data.results
        console.log(result); 
        heroList = result; // { "userId": 1, "id": 1, "title": "...", "body": "..." }
        createSuperHeroList(result)
    });
//   });

function createSuperHeroList(list) {
    let heroWrapper = document.querySelector('.heroList')
    list.forEach((element,index) => {
        let nodeWrapper = document.createElement('div');
        nodeWrapper.className = 'heroWrapper'
        let imageNode = document.createElement('img');
        imageNode.src = element.thumbnail.path + "/portrait_incredible."
            + element.thumbnail.extension
        let headingNode = document.createElement('div');
        headingNode.className = 'heroName'
        headingNode.appendChild(document.createTextNode(element.name));
        nodeWrapper.appendChild(imageNode);
        nodeWrapper.appendChild(headingNode);
        nodeWrapper.addEventListener("click", function() {
            heroDetails(element)
        });
        heroWrapper.appendChild(nodeWrapper)
    })
}

function clearList() {
    let heroWrapper = document.querySelector('.heroList')
        heroWrapper.innerHTML='';
}


function heroDetails(data) {
    console.log("hero data--->", data);
    localStorage.setItem("heroData", data.id)
    window.open("../html/hero.html", "_self")
    return data;
}





